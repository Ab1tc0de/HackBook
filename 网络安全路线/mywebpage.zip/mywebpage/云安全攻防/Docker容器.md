# Docker容器

&nbsp;


## docker安装

### 【Linux端安装】

* **ubuntu安装docker**
  * （1）如果已安装过Docker, 需要移除老版本的Docker
    ```bash
    sudo apt-get remove docker docker-engine docker.io containerd runc
    ```
    
  * （2）使用Docker repository
    ```bash
    # 更新apt包索引
    sudo apt-get update
    
    # 为支持https
    sudo apt-get install \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg-agent \
    software-properties-common
    
    # 添加Docker GPG秘钥
    # 国内源
    curl -fsSL https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu/gpg | sudo apt-key add -
    # 或者国外源
    # curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
    
    # 添加安装源
    # 推荐国内源
    sudo add-apt-repository \
    "deb [arch=amd64] https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu \
    $(lsb_release -cs) \
    stable"
    # 或者国外源
    # sudo add-apt-repository \
    #   "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
    #   $(lsb_release -cs) \
    #   stable"
    ```
    
  * （3）安装Docker
    ```bash
    # 更新apt包索引
    sudo apt-get update
    
    # 安装docker
    sudo apt-get install docker-ce docker-ce-cli containerd.io
    ```
    
  * （4）开启开机自启动
    ```bash
    sudo systemctl enable docker
    sudo systemctl start docker
    ```
  
* **centos安装**
  * （1）移除老版本
    ```bash
    sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
    ```
  * （2）添加Docker repository yum源
     ```bash
     # 国内源, 速度更快, 推荐
    sudo yum-config-manager \
    --add-repo \
    https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo
    # 官方源, 服务器在国外, 安装速度慢
    # $ sudo yum-config-manager \
    #     --add-repo \
    #     https://download.docker.com/linux/centos/docker-ce.repo
    ```
  * （3）安装docker
    ```bash
    sudo yum makecache fast
    sudo yum install docker-ce docker-ce-cli containerd.io
    ```
    
  * （4）开启docker
    ```bash
    sudo systemctl enable docker
    sudo systemctl start docker
    ```
    
&nbsp;


## docker命令

### 【docker基础命令】

* 搜索容器
  ```bash
  docker search <镜像名称>
  ```
  
* 获取镜像
  ```bash
  docker pull <镜像名称>
  docker pull index.tenxcloud.com/tenxcloud/httpd   获取第三方容器
  ```
  
* 列出所有镜像
  ```bash
  docker image list
  docker images
  ```

* 导出导入镜像
  ```bash
  docker image save ubuntu > docker_ubuntu.tar.gz  导出镜像
  docker image load -i docker_ubuntu.tar.gz   导入镜像
  ```
  
### 【容器的使用】


