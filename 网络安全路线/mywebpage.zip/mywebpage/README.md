# BitCode Hack Hand Book
>主要对于渗透测试方面的研究

&nbsp;

# 概述
**Bitcode Hack包含了各方面渗透测试知识，其中包含内网渗透和移动渗透知识，通过精要的语言阐述了计算机方面的各种技巧，其中还包含各种实用开源工具。**

&nbsp;

# 文章框架
**从入门到弃坑，将大部分渗透难点包含在内**
* Linux基础
* 渗透测试方法论
* 内网渗透
* 移动渗透
* 等等...

&nbsp;

# About me
**一些示例代码可以在[Bitcode github](/aaaaaaa)中下载**

&nbsp;

***
Power by docsify

